function displayMessage() {
    document.getElementById("message").textContent = "Hello, IPFS World!";
}
